# AUDIT_PROTOCOL.md

**Purpose:** Defines how Claude audits ClaudeCode's work before Barbara authorizes merge/deploy. Prevents "trust without verify" failures that caused past drift.

---

## WHEN AUDIT IS REQUIRED

Claude MUST audit when:
- ClaudeCode completes any task with TASK_CLOSEOUT_REPORT
- Before any merge to `main`
- Before any deploy to production
- Before any PR is approved
- When Barbara is uncertain about a claimed fix

Claude MAY skip audit only when:
- Task is purely read-only discovery (e.g., inventory commands)
- Task is documentation only (no code changes)

**When in doubt, audit. Audit is cheap. Regression is expensive.**

---

## AUDIT DELIVERABLE

Claude produces `AUDIT_REPORT_<task_id>_<date>.md` with verdict:

- **APPROVED** — task may proceed to merge/deploy
- **APPROVED_WITH_NOTES** — proceeds but with documented caveats
- **REJECTED** — task must be redone, explicit reasons given
- **ESCALATE** — beyond Claude's ability to verify, needs Barbara or external second opinion

---

## AUDIT CHECKLIST

For each task, Claude verifies the following. Every box must be checked — if any fails, verdict is at minimum APPROVED_WITH_NOTES, possibly REJECTED.

### 1. Spec compliance
- [ ] Every numbered instruction in task spec Section 4 has evidence in closeout Section 1 (FIXED/PARTIAL/NOT_ADDRESSED)
- [ ] No instruction silently ignored
- [ ] All PARTIAL/NOT_ADDRESSED have acceptable justification

### 2. Scope lock adherence
- [ ] `git diff --name-only` shows only files listed in task spec Section 4
- [ ] No logging/observability added beyond spec
- [ ] No adjacent refactors
- [ ] No unrelated bugfixes (flagged in closeout Section 6 instead — correct behavior)
- [ ] No renames, reformats, or docstring changes beyond necessity
- [ ] No config files touched unless specified

### 3. Git hygiene
- [ ] Branch created from `origin/main` (not from old state)
- [ ] Commit hash valid and matches closeout report
- [ ] PR opened (if applicable), not merged directly
- [ ] No force-pushes, rebases, or history rewrites

### 4. Proof of execution validity
- [ ] Full diff provided, not truncated
- [ ] Line numbers match current file state (re-verify by cloning and grep)
- [ ] Before/after snippets accurate

### 5. Proof of functionality validity
- [ ] Tests from task spec Section 8 actually executed (not just described)
- [ ] Outputs match expected
- [ ] Tests cover the actual changed code paths (not tangential)

### 6. Proof of no-regression validity
- [ ] Preservation strings all found
- [ ] py_compile passes for all specified files
- [ ] Behavior checks (if any) performed
- [ ] No "rollback indicator" present — check for silent reverts of previous work

### 7. Methodology alignment
- [ ] Changes consistent with `APEX_METHODOLOGY_GROUND_TRUTH.md`
- [ ] Changes consistent with relevant `MODULE_DESIGN_DOC.md`
- [ ] No introduction of rules that violate Section 7 of ground truth
- [ ] No strategies silently disabled

### 8. Self-assessment honesty
- [ ] ClaudeCode's answers in closeout Section 10 are consistent with the evidence
- [ ] Confidence score plausible given the evidence
- [ ] No claims in excess of what diff actually shows

### 9. Technical debt assessment
- [ ] Technical debt flagged in closeout Section 7 is acceptable
- [ ] If not acceptable, added to SYSTEM_STATE_LOG open items

### 10. State update readiness
- [ ] `SYSTEM_STATE_LOG.md` update proposal (closeout Section 12) is correct
- [ ] No state change hidden (e.g., new file, new config key, new feature flag)

---

## CROSSCHECK COMMANDS (for Claude to run)

When auditing, Claude runs these independently — not trusting ClaudeCode's output:

```bash
# Clone fresh copy
git clone <repo> /tmp/audit_<timestamp>
cd /tmp/audit_<timestamp>
git checkout <branch>

# Verify diff matches claim
git diff origin/main..HEAD --stat
git diff origin/main..HEAD

# Verify claimed line numbers
grep -n "<key_string>" <file>

# Verify no-regression of previous work
for needle in <preservation_strings>; do
  grep -c "$needle" <file> && echo "$needle: preserved" || echo "$needle: LOST"
done

# Compile check
python -m py_compile <files>

# Scope compliance
git diff --name-only origin/main..HEAD
```

The output of these commands goes into the audit report Section "Independent Verification".

---

## AUDIT REPORT TEMPLATE

```markdown
# AUDIT REPORT — Task [ID]

**Audited by:** Claude
**Date:** [YYYY-MM-DD]
**Task spec reviewed:** [path]
**Closeout report reviewed:** [path]
**Commit audited:** [hash]

## Verdict

[APPROVED | APPROVED_WITH_NOTES | REJECTED | ESCALATE]

## Executive summary

[2-3 sentences: what was done, does it hold up, main concerns if any]

## Checklist results

[copy the 10-section checklist above, marked with results]

## Independent verification

[outputs of crosscheck commands run by Claude]

## Findings

### Critical issues
[if any — must block merge]

### Concerns
[acceptable but noted]

### Commendations
[what was done particularly well — useful positive reinforcement]

## Recommendations

[what Barbara should do next]

## Sign-off

Auditor: Claude
Approved for: [merge | deploy | escalation]
Conditions: [if any]
```

---

## WHEN TO ESCALATE

Claude escalates (rather than approving/rejecting) when:
- The evidence is valid but Claude cannot assess methodological correctness (e.g., uses GC-specific knowledge outside Claude's certainty range)
- The task spec itself had ambiguity that ClaudeCode interpreted reasonably but not canonically
- Barbara explicitly wants second opinion (ChatGPT, Gemini, human expert)
- The change has production-safety implications beyond code (e.g., broker integration nuances)

Escalation is not weakness — it is the correct response to epistemic uncertainty.

---

## AUDIT DEFENSE

If ClaudeCode disputes an audit finding:
1. ClaudeCode presents counter-evidence
2. Claude re-examines specific claim
3. If Claude is wrong, corrects the audit and documents the correction
4. If ClaudeCode is wrong, audit stands
5. If irreducible disagreement, escalate to Barbara

**Neither Claude nor ClaudeCode may override the other. Barbara is final arbiter.**

---

## RETENTION

All audit reports are archived in `Docs/Audit_Reports/` alongside the task spec and closeout. This creates a historical trail: if a bug appears in production, we can trace back through the audit chain and identify where verification failed.
