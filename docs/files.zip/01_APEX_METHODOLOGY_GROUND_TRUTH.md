# APEX_METHODOLOGY_GROUND_TRUTH.md

**Status:** DRAFT v0.1 — awaiting Barbara review
**Version:** 0.1
**Date:** 2026-04-17
**Owner:** Barbara (FluxFoxLabs)
**Author:** Claude (ML/AI Engineer)
**Purpose:** Single source of truth for APEX trading methodology. All design documents, code, and decisions reference this document.

---

## CRITICAL USAGE RULE

**This document is the ONLY place where methodology "truth" is defined. If another document, code comment, Telegram message, or decision contradicts this document, this document wins.** Changes to methodology happen by updating THIS document first, then propagating to code.

---

## 1. WHAT APEX IS

APEX is a rule-based algorithmic trading system for XAU/USD (Gold Futures GC via Quantower/dxfeed, executed on MT5 XAUUSD via RoboForex and Hantec brokers).

It implements a hybrid methodology combining:
- **ATS** (Adaptive Trading System) — structural framework and entry patterns
- **Wyckoff** — phase analysis and effort-vs-result reasoning
- **ICT** (Inner Circle Trader) — intraday execution timing and order flow

All three methodologies reinforce each other. **The system must remain faithful to all three simultaneously** — any decision that satisfies one while violating another is wrong.

---

## 2. PRIMARY TIMEFRAME HIERARCHY (ADR-001, PERMANENT)

| Timeframe | Role | Source methodology |
|---|---|---|
| W1 | Weekly alignment (directional context only) | ATS/Wyckoff |
| D1 | Daily bias (directional context only) | ATS/Wyckoff |
| H4 | Momentum confirmation | ICT (displacement) |
| **M30** | **EXECUTION timeframe (entries, exits)** | **ATS (structural)** |
| M5 | Execution refinement (trigger precision) | ICT (kill zones) |
| Ticks | Microstructure context | ICT (order flow) |

**M30 is the execution timeframe. D1/W1 NEVER generate entries. H4 NEVER generates entries. Entries happen on M30 box structure, refined by M5 triggers.**

---

## 3. THE PHASE MODEL (Wyckoff applied)

At any moment, the market is in exactly one of three phases. The phase determines which strategy is active:

| Phase | Description | Active Strategy |
|---|---|---|
| **CONTRACTION** | Price inside M30 box, range-bound | RANGE_BOUND (mean-revert to FMV) |
| **EXPANSION** | Breakout in progress, not yet sustained | TREND_FOLLOWING (pullback entries) |
| **TREND** | Breakout confirmed, directional move established | TREND_FOLLOWING (aggressive, hold runners) |

*[PLACEHOLDER: add phase transition diagram + concrete examples with GC charts]*

**Key ATS quote (to preserve):** "Your effectiveness as a trader is directly proportional to your ability to recognize which phase the market is currently in."

---

## 4. STRATEGIES IMPLEMENTED (not just one!)

**⚠️ CRITICAL:** Past audits revealed that the live system was running only ONE strategy despite multiple being in the plan. This is FORBIDDEN. APEX must implement all strategies listed below. A code path that silently disables a strategy is a bug.

### 4.1 RANGE_BOUND (active during CONTRACTION phase)
- Entry: reversal at liq_top (SHORT) or liq_bot (LONG) targeting FMV
- Source: ATS "Market Maker" strategy
- Reasoning: price accumulates/distributes against deviation, liquidates at value

### 4.2 TREND_FOLLOWING — Pullback (active during EXPANSION/TREND phase)
- Entry: pullback to expansion line in direction of trend
- Source: ATS Strategy 2 (Trending Markets)
- Reasoning: enter on retracement, not on breakout itself

### 4.3 TREND_FOLLOWING — Continuation (active during TREND phase)
- Entry: continuation setup after consolidation within trend
- Source: ATS + ICT (displacement-confirmed continuation)
- Reasoning: momentum resumption after micro-pullback

### 4.4 REVERSAL (overextension / exhaustion)
- Entry: SHORT at liq_top when price is overextended above it (in LONG trend, exhaustion signal); LONG at liq_bot when overextended below (SHORT trend, exhaustion)
- Source: Wyckoff UTAD (Upthrust After Distribution) / Spring, ICT liquidity sweep
- Reasoning: excess move past structural level indicates terminal exhaustion, not continuation
- **NOT to be confused with pullback** — reversal is REGIME change, pullback is temporary retracement within trend
- **Safe guard:** runners close on REVERSAL detection (regime flip), never on pullback

### 4.5 Additional strategies [PLACEHOLDER — Barbara to confirm completeness]
- ORB (Opening Range Breakout) — from original vision, not yet implemented
- Mean Reversion fade — from original vision, not yet implemented
- [others?]

---

## 5. ENTRY TYPES (ALPHA / GAMMA / DELTA)

*[PLACEHOLDER: Barbara, I need your definitive explanation of these three types and when each applies. From code I can see they exist but I want YOUR ground truth, not my inference. Please draft this section.]*

---

## 6. THE 4-GATE ENTRY SYSTEM

All entries (ALPHA/GAMMA/DELTA) pass through 4 sequential gates. Each can approve (+score), penalize (-score), or veto (BLOCK).

### Gate 1 — M30 Structure
- Purpose: confirm price is in a valid structural context (inside box or at expansion line)
- Blocks: box unconfirmed, weekly not aligned, ATR in extreme regime, distance too far from level
- Source: ATS (box structure, weekly alignment, volatility regime)

### Gate 2 — L2 Entry Score
- Purpose: confirm institutional pressure supports direction
- Score: l2_entry_score = aggregate of (DOM imbalance, absorption, LOI, sweep, POC, pressure)
- Threshold: ≥65 to pass
- Source: ICT order flow + OrderStorm principles

### Gate 3 — Momentum / Delta 4H
- Purpose: block trades against cumulative delta (institutional positioning)
- Blocks: delta_4h above SHORT_BLOCK or below LONG_BLOCK (calibrated CAL-16/17)
- Source: Order flow momentum (Orderflows.com Module 4)

### Gate 4 — Iceberg / Grenadier
- Purpose: confirm no iceberg order opposing direction + no data anomaly
- Blocks: iceberg contra (binary BLOCK, not score), Grenadier stale data veto
- Source: Iceberg detection literature (CME, Ninjacators, Bookmap)

*[PLACEHOLDER: Barbara, expand each gate with the specific calibrated thresholds that must be preserved — CAL-1 to CAL-13, CAL-16/17. These are currently in settings.json but should be documented here as methodology ground truth.]*

---

## 7. INVIOLABLE OPERATIONAL RULES

These rules CANNOT be broken by any code path. Any module that violates these is incorrect.

1. **Single-direction authority:** Direction is decided by ONE source. The system must NOT have two modules independently deciding direction and then arguing downstream.
2. **Hard-block on iceberg contra:** If an iceberg opposes the intended direction, the trade does NOT open. Not reduced score — BLOCK.
3. **No trades during stale feed:** If microstructure feed is stale beyond threshold, trading is DISABLED globally, not silently ignored.
4. **Runners close on REVERSAL only:** Runners are not closed on pullback, noise, or temporary adverse movement. They close when regime flip is confirmed.
5. **M30 is execution timeframe:** No entry is triggered on D1, W1, or H4. They provide context only.
6. **Confirmed bias only for hard veto:** M30 bias used as hard veto must come from confirmed M30 box, never from unconfirmed/provisional state.
7. **3-leg entry structure:** Every entry opens 3 legs (Leg1 + Leg2 + Runner) with sizing per session table.
8. **Lot sizing table (Barbara-approved):** ASIAN=[0.01,0.01,0.01], LONDON=[0.02,0.02,0.01], NY=[0.03,0.02,0.01]. Iceberg aligned adds +0.01 to Leg1 and Leg2 only. Runner NEVER changes.
9. **News veto:** During high-impact news window, entries are BLOCKED and existing positions managed per news policy.
10. **Dual broker independence:** RoboForex and Hantec are independent execution channels. Failure in one MUST NOT prevent execution in the other.

*[PLACEHOLDER: Barbara, add any inviolable rules I missed. These are the "never" list — rules whose violation is always a bug regardless of context.]*

---

## 8. METHODOLOGY SOURCE DOCUMENTS

Authoritative sources (in project knowledge):
- **ATS:** ATS_Basic_Strategy_1_Range_Bound_Markets.txt, ATS_Trading_Strategy_2_Trending_Markets.txt, ATS_Core_Components_Overview.txt, Everything_to_Know_About_Boxes.txt, ATS_Implementation_Strategic_Plan.txt
- **Wyckoff:** Wyckoff-Methodology-in-Depth-Ruben-Villahermosa.pdf, Wyckoff_2_0_Structures__Volume_Prof.pdf
- **ICT:** ICT_Handbook.pdf, 652432368-Ict-Institutional-Smc-Trading.pdf, Module1-5 Orderflows
- **Iceberg:** CME_Iceberg_Detection, Ninjacators iceberg ebook, El_impacto_de_las_ordenes_iceberg, Iceberg_Orders_Tracker
- **Master spec:** FUNC_V3_RL_Predictive_Model, APEX_GC_Methodology_FitGap_v2, APEX_GC_FitGap_Analysis_vs_Vision

Any design decision that contradicts these sources requires explicit documented justification.

---

## 9. CHANGE LOG

| Date | Version | Change | Approved by |
|---|---|---|---|
| 2026-04-17 | 0.1 | Initial draft | Pending Barbara review |

---

## 10. PENDING SECTIONS (Barbara input required)

- [ ] Section 5 — Entry types ALPHA/GAMMA/DELTA formal definitions
- [ ] Section 6 — Gate threshold documentation (calibrations CAL-*)
- [ ] Section 7 — Additional inviolable rules I may have missed
- [ ] Section 4.5 — Completeness of strategy list

---

**Next review:** Barbara reviews, we refine in 1-2 iterations, then v1.0 becomes the locked ground truth.
