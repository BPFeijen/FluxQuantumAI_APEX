# SYSTEM_STATE_LOG.md

**Status:** LIVING DOCUMENT — updated at end of every session
**Purpose:** The "map of the territory" — state of the APEX system at any moment. Allows any new session (Claude, ClaudeCode, Barbara with fresh eyes) to understand current state in 5 minutes.

---

## HOW TO USE

- **Updated by:** Claude at end of each session (or by ClaudeCode if task modifies system state)
- **Reviewed by:** Barbara
- **Read by:** Everyone starting a new session — this is the first document to read
- **Updates go in dedicated section (bottom) with timestamp** — no silent overwrites, history preserved

---

# APEX SYSTEM STATE

**Last updated:** 2026-04-17 [by Claude, initial draft]

---

## 1. PRODUCTION STATUS

**Environment:** Live production
**Server:** Windows server, path `C:\FluxQuantumAI\`
**Status:** RUNNING but with known issues (94% block rate, 72% EXEC_FAILED on approvals)
**Services:** [PLACEHOLDER — awaiting discovery report from ClaudeCode]

**Brokers:**
- RoboForex (demo): [status — awaiting confirmation]
- Hantec (live): [status — awaiting confirmation]

**Instrument:** GC (Gold Futures via Quantower/dxfeed) → MT5 XAUUSD execution

---

## 2. ACTIVE CODE VERSION

**Live in production server:**
- Code is INTACTO from GitHub — diverges from any commit in repo
- Has all 12 bugs from `CURRENT_LIVE_CODE_AUDIT.md` active
- No deploys since [date — awaiting Barbara confirmation]

**GitHub `main` (commit `ee2068d`):**
- Has 7 of 12 bugs from audit FIXED (Issues #4, #7, #10, #11, #12 + execution reconciliation + PM canonical events)
- Has Issues #1, #2, #3 (partial), #5, #6, #8, #9 NOT addressed or only partially
- Not yet deployed to server

**Local patch prepared by Claude (`fix_p0_issues_1_and_2.patch`):**
- Addresses Issues #1 and #2 on top of `main`
- Not yet deployed

**GitHub `work` branch:**
- Separate refactor initiative (modular decomposition)
- IGNORE for current stabilization purposes
- Will be addressed in separate track after APEX stable

---

## 3. KNOWN ACTIVE BUGS (production)

| # | ID | Severity | Description | Fix location |
|---|---|---|---|---|
| 1 | Audit#1 | P0 | `price` undefined in `_check_pre_entry_gates` | In patch |
| 2 | Audit#2 | P0 | Boolean precedence in `_detect_box_ladder` | In patch |
| 3 | Audit#4 | High | PATCH2A vs M30_BIAS_BLOCK conflict | In `main` |
| 4 | Audit#7 | Critical | Unconfirmed bias used as hard veto | In `main` |
| 5 | Audit#10 | High | Tick breakout mutation without macro sync | In `main` |
| 6 | Audit#11 | High | Stale feed not escalated to trading-disable | In `main` |
| 7 | Audit#12 | Medium | Duplicated bias derivation | In `main` |
| 8 | Audit#3 | High | Dual direction authority (architectural) | Partial in `main`, full fix pending |
| 9 | Audit#5 | [DISPUTED] | TRENDING reversal fallback | Not a bug — methodology feature |
| 10 | Audit#6 | High | daily_trend proxy lag-prone | NOT fixed — pending backtest + literature |
| 11 | Audit#8 | Medium | M5/M30 validation log-only | NOT fixed |
| 12 | Audit#9 | High | Veto stacking pre-scoring | NOT fixed (observability improved) |

---

## 4. DEPLOYED CALIBRATIONS (preserve)

| CAL-ID | Parameter | Value | Status |
|---|---|---|---|
| CAL-1 | iceberg_absorption_ratio | 12.28 | DEPLOYED |
| CAL-2 | iceberg_LOI_threshold | 0.14 | DEPLOYED |
| CAL-3 | iceberg_weights_rebalance | [pending] | OFF |
| CAL-4 | iceberg_collision_band | 1.60 pts | DEPLOYED |
| CAL-5 | iceberg_collision_lookback | 3 min | DEPLOYED |
| CAL-6 | breaking_ice_exceed | 2.20 pts | DEPLOYED |
| CAL-7 | breaking_ice_lookback | 4 min | DEPLOYED |
| CAL-8 | iceberg_zones_proximity | [pending] | OFF |
| CAL-9 | MFE_giveback_threshold | [pending] | OFF |
| CAL-10 | MFE_giveback_min_profit | [pending] | OFF |
| CAL-11 | trailing_ATR_mult | [pending] | OFF |
| CAL-12 | trailing_floor/ceiling | 5.11 / 30.64 | DEPLOYED |
| CAL-13 | value_stacking_min_boxes | 3 | DEPLOYED |
| CAL-16 | delta_4h_LONG_block | -1050 | DEPLOYED |
| CAL-17 | delta_4h_SHORT_block | +3000 | DEPLOYED |

**Lot sizing (Barbara-approved):**
- ASIAN: [0.01, 0.01, 0.01]
- LONDON: [0.02, 0.02, 0.01]
- NY: [0.03, 0.02, 0.01]
- Iceberg aligned bonus: Leg1 +0.01, Leg2 +0.01, Runner never changes

**All calibrations live in `settings.json` — must be preserved across deploys.**

---

## 5. ACTIVE FEATURE FLAGS

| Flag | State | Since | Notes |
|---|---|---|---|
| dual_strategy | ON (ATR=1.5) | Sprint 8 deploy | Backtest 10 months: PF 0.96→1.08 |
| delta_4h_inverted_fix | ON | Sprint 8 deploy | — |
| trade_cooldown_enabled | ON (30/60 min) | Sprint 8 deploy | — |
| iceberg_hard_block_on_contra | ON | Sprint 4 | TYPE 4 JSONL contra |
| dynamic_lot_sizing_enabled | OFF | default | — |
| iceberg_collision_enabled | OFF | default | CAL pending deploy |
| breaking_ice_enabled | OFF | default | CAL pending deploy |
| iceberg_zones_enabled | OFF | default | CAL pending deploy |

---

## 6. ML/DATA PIPELINE STATUS

**Iceberg:**
- V1 rule-based: PRODUCTION
- V2 ML: retraining on SageMaker (4 heads)

**Anomaly:**
- L1 rules + Grenadier Z-score: ACTIVE
- V3 L2 autoencoder: FAILED (MSE ~1.0 vs expected 5.89e-07)
- V4 Conv1D AE on DOM snapshots: SPEC created, training pending

**Data:**
- Databento → microstructure conversion: 126 days running
- Unified backtest (V4 + IceV2 + gates): PENDING post-conversion

---

## 7. OPEN STRATEGIC DECISIONS

1. **Issue #6 (daily_trend)** — data-driven threshold via backtest + literature review. Barbara-approved approach. Target: post-deploy stabilization.
2. **Issue #3/#10 (direction authority)** — architectural fix pending. Partial fix in `main` addresses symptoms.
3. **Refactor of live monolith** — `work` branch has modular decomposition in progress (ChatGPT + Codex led). Paused until Claude reviews alignment with NextGen blueprint.
4. **NextGen project** — separate 100% ML/RL/DL initiative. Not touching APEX directly.

---

## 8. PROCESS ARTIFACTS IN USE

- `APEX_METHODOLOGY_GROUND_TRUTH.md` — source of truth (v0.1 draft)
- `MODULE_DESIGN_DOC_TEMPLATE.md` — design template
- `CLAUDECODE_TASK_SPEC_TEMPLATE.md` — task spec template
- `TASK_CLOSEOUT_REPORT_TEMPLATE.md` — closeout template
- `SYSTEM_STATE_LOG.md` — this document
- `AUDIT_PROTOCOL.md` — audit procedure (6th artifact)

**Golden rule:** No code without approved design doc. No merge without audit. No session end without closeout + state log update.

---

## 9. NEXT PLANNED WORK

1. **[IN PROGRESS]** APEX stabilization deploy (fixes #1, #2 + `main` code to server)
2. **[PENDING]** Issue #6 backtest + literature (post-deploy)
3. **[PENDING]** Complete `APEX_METHODOLOGY_GROUND_TRUTH.md` v1.0 (Barbara input on sections 4.5, 5, 6, 7)
4. **[PENDING]** Review `work` branch alignment with NextGen blueprint
5. **[PENDING]** P1 Phase Detector design doc (for NextGen)

---

## 10. CHANGE LOG

| Date | Change | By |
|---|---|---|
| 2026-04-17 | Initial draft created | Claude |

---

## 11. HOW TO UPDATE THIS DOCUMENT

At the end of every session that modifies any part of APEX:

1. Add entry to section 10 (change log) with date + what changed + who
2. Update relevant sections (production status, bugs, calibrations, etc.)
3. If open decisions were resolved, move them from section 7 to relevant section
4. Commit updated document to project knowledge

**Never delete historical entries — only mark superseded.**
