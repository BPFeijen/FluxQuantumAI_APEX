# TASK_CLOSEOUT_REPORT_TEMPLATE.md

**Purpose:** Template ClaudeCode must fill after every task. Prevents "silent success" where work is claimed done without proof. Auditable by Claude before merge/deploy.

---

## HOW TO USE

1. ClaudeCode fills this AFTER completing task work
2. Report is submitted to Barbara (and Claude for audit)
3. Claude audits against the original task spec + design doc
4. Only if audit passes: merge/deploy authorized
5. Report is archived in project knowledge (`Docs/Task_Closeouts/`)

---

# TASK CLOSEOUT REPORT — [Task ID]

**Task ID:** [YYYYMMDD-nnn]
**Task spec:** [CLAUDECODE_<name>_<date>.md]
**Date executed:** [YYYY-MM-DD]
**Executor:** ClaudeCode
**Branch:** [branch_name]
**Commit hash:** [hash]

---

## 1. INSTRUCTION STATUS MATRIX

For EACH numbered instruction in the original task spec Section 4:

| Instruction # | Description (short) | Status | Evidence |
|---|---|---|---|
| 1 | [...] | FIXED / PARTIAL / NOT_ADDRESSED / SKIPPED_WITH_REASON | [file:line or command output] |
| 2 | [...] | [...] | [...] |

**Status definitions:**
- **FIXED:** Instruction fully completed as specified
- **PARTIAL:** Partially completed — must explain what's missing and why
- **NOT_ADDRESSED:** Not done — must explain why (if valid reason) or flag as failure
- **SKIPPED_WITH_REASON:** Intentionally skipped with justification — requires Claude's audit approval

**If any row is PARTIAL or NOT_ADDRESSED without valid reason, this task is NOT complete.**

---

## 2. SCOPE COMPLIANCE CHECKLIST

For each item in the original Section 5 (scope lock):

- [ ] Only modified files listed in Section 4? [Y/N — if N, explain]
- [ ] No adjacent refactors? [Y/N]
- [ ] No logging/observability additions beyond spec? [Y/N]
- [ ] No other bug fixes during this task? [Y/N]
- [ ] No renamings unless instructed? [Y/N]
- [ ] No docstring changes beyond necessity? [Y/N]
- [ ] No config file changes unless instructed? [Y/N]
- [ ] No new files unless instructed? [Y/N]

**If any is N without strong justification, task fails scope compliance.**

---

## 3. PROOF OF EXECUTION

### 3.1 Git evidence
```
[paste output of: git log --oneline <base>..HEAD]
[paste output of: git diff --stat <base>..HEAD]
```

### 3.2 Full diff
```
[paste output of: git diff <base>..HEAD]
(NOT truncated, NOT summarized — the literal full diff)
```

### 3.3 Files changed
```
[paste output of: git diff --name-only <base>..HEAD]
```

---

## 4. PROOF OF FUNCTIONALITY

Run each test specified in original task spec Section 8. Paste the literal output of each.

### Test 1
```bash
[command]
```
Output:
```
[literal stdout]
```
Result: PASS / FAIL

### Test 2
[...]

---

## 5. PROOF OF NO-REGRESSION

Run each check specified in original task spec Section 9.

### Preservation check
```bash
[grep or other command]
```
Output:
```
[literal]
```
Status: [all expected strings found / some missing — which?]

### Compile check
```bash
[py_compile or other]
```
Exit code: [0 / nonzero with details]

### Behavior check (if applicable)
[details]

---

## 6. BUGS ENCOUNTERED BUT NOT FIXED

[List every bug, anomaly, or unexpected behavior noticed during this task that was NOT in the task scope. Do NOT fix them — just list here.]

For each:
- **Location:** file:line
- **Description:** what you saw
- **Why not fixed:** (out of scope)
- **Recommended action:** (new task? / ignore? / urgent?)

---

## 7. TECHNICAL DEBT LEFT

[Shortcuts taken, TODOs added, patterns not ideal. Be honest — this is how we avoid silent decay.]

| Item | Location | Why | Recommended future action |
|---|---|---|---|
| [...] | [...] | [...] | [...] |

---

## 8. UNEXPECTED BEHAVIOR OR STATE

[If production/server state was different from what the task spec assumed, describe here.]

---

## 9. FILES MODIFIED BEYOND ORIGINAL SCOPE

[If any file outside Section 4 was touched — describe exactly and explain why. This should almost always be empty.]

---

## 10. SELF-ASSESSMENT

Answer honestly. These questions exist to prevent over-claiming.

1. Did you literally follow scope lock, or did you interpret it? **[Y/N + explanation]**
2. Are all instruction rows in Section 1 objectively verifiable, or did any require interpretation? **[Y/N]**
3. If you had to choose between "fix quickly" and "stay in scope", which did you choose? **[answer]**
4. Is there anything in this diff that Barbara/Claude would be surprised to find? **[Y/N]**
5. On a scale 1-5, how confident are you this task is production-ready? **[n + justification]**
6. What would you do differently if you started this task over? **[answer]**

---

## 11. HANDOFF NOTES FOR NEXT SESSION

[If this work continues, what does the next person/session need to know? Decisions made, context learned, gotchas discovered.]

---

## 12. PROPOSED UPDATE TO SYSTEM_STATE_LOG.md

[What changes to the living state log should be made as a result of this task? Claude will verify and apply.]

---

**ClaudeCode: this closeout report is submitted to Barbara and Claude. Do NOT merge, deploy, or consider the task complete until Claude audit returns APPROVED.**
