# MODULE_DESIGN_DOC_TEMPLATE.md

**Purpose:** Template for designing any new module or substantial refactor in APEX (or future NextGen). **No code is written until this document is filled in and approved by Barbara.**

---

## HOW TO USE

1. Copy this template, rename to `<module_name>_DESIGN_DOC.md`
2. Fill ALL sections. No placeholders like "TBD" in final version.
3. Submit to Barbara for review
4. Iterate until Barbara marks STATUS: APPROVED
5. Only then does ClaudeCode receive a task spec based on this design

---

# [MODULE_NAME] — Design Document

**Status:** DRAFT | IN_REVIEW | APPROVED | SUPERSEDED
**Version:** [x.y]
**Date:** [YYYY-MM-DD]
**Author:** Claude (ML/AI Engineer)
**Approved by:** Barbara (signature date: [YYYY-MM-DD])
**Supersedes:** [previous design doc if applicable]

---

## 1. PURPOSE

[One paragraph — why this module exists, what problem it solves]

## 2. METHODOLOGY REFERENCE

**This module implements:**
- [Specific section(s) of APEX_METHODOLOGY_GROUND_TRUTH.md — cite by section number]
- [Specific literature sources with page/section references]

**Methodology rules this module MUST respect:**
- [List from Section 7 of ground truth that apply]

**Methodology rules this module MUST NOT interact with:**
- [Explicit list — prevents scope creep]

## 3. RESPONSIBILITIES

**This module IS responsible for:**
- [bullet list, be specific]

**This module IS NOT responsible for:**
- [bullet list — critical for avoiding monolithic drift]

## 4. INPUTS (CONTRACT)

| Input | Source | Format | Frequency | Validation |
|---|---|---|---|---|
| [name] | [module/file] | [type/schema] | [when] | [how to validate] |

## 5. OUTPUTS (CONTRACT)

| Output | Consumer | Format | Frequency | Guarantees |
|---|---|---|---|---|
| [name] | [module/file] | [type/schema] | [when] | [what is promised] |

## 6. DECISION LOGIC

[Pseudocode or flowchart of the module's core logic. Must be readable by Barbara without code background.]

## 7. ERROR HANDLING

| Failure Mode | Detection | Response |
|---|---|---|
| [scenario] | [how we detect] | [what module does — never silent failure] |

**Fail-safe default:** [what the module does when uncertain — should default to safe/blocking, never to risky/permissive]

## 8. CONFIGURATION (settings.json keys)

| Key | Type | Default | Meaning | Calibration status |
|---|---|---|---|---|
| [key] | [type] | [val] | [desc] | CALIBRATED / DEFAULT / PLACEHOLDER |

## 9. ACCEPTANCE CRITERIA

[Numbered list of testable criteria. Each criterion must be objectively verifiable — no "works correctly" handwaving.]

1. Given [input X], module returns [output Y]
2. Given [failure mode Z], module [expected response]
3. [etc.]

## 10. TEST PLAN

- **Unit tests:** [what to test in isolation]
- **Integration tests:** [what to test with dependencies]
- **Backtest:** [what historical data to replay, expected metrics]
- **Shadow run:** [if needed, how long and with what comparison]

## 11. PRODUCTION OBSERVABILITY

**Canonical outputs this module emits:**
- [to decision_log.jsonl? position_events.jsonl? other?]

**Logs this module writes:**
- [paths + what they contain]

**Metrics/KPIs to monitor:**
- [what signals healthy vs broken behavior]

## 12. DEPENDENCIES

**Upstream (modules this reads from):**
- [list]

**Downstream (modules that read from this):**
- [list]

**External:**
- [libraries, broker APIs, file paths]

## 13. ROLLOUT PLAN

1. **Phase 1 (dev):** [what]
2. **Phase 2 (shadow):** [what, duration, success criteria]
3. **Phase 3 (live):** [what, how to switch, kill switch]

## 14. ROLLBACK PLAN

If this module causes production issue, rollback procedure:
1. [step 1]
2. [step 2]

## 15. OPEN QUESTIONS

[Things unresolved that Barbara needs to decide before APPROVED]

## 16. CHANGE LOG

| Date | Version | Change | Author |
|---|---|---|---|
| [YYYY-MM-DD] | x.y | [change] | [who] |
