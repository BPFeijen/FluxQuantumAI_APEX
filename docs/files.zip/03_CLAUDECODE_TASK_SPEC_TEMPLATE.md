# CLAUDECODE_TASK_SPEC_TEMPLATE.md

**Purpose:** Template for any task delegated to ClaudeCode. **No task is sent without using this template.** Prevents scope creep and ensures auditability.

---

## HOW TO USE

1. Copy template, rename to `CLAUDECODE_<task_name>_<date>.md`
2. Fill every section — no skipping
3. Reference the approved MODULE_DESIGN_DOC (if structural work)
4. Send to ClaudeCode with the referenced design doc attached
5. After ClaudeCode completes, audit the TASK_CLOSEOUT_REPORT against this spec

---

# TASK: [short clear name]

**Task ID:** [YYYYMMDD-nnn]
**Date:** [YYYY-MM-DD]
**Priority:** P0 | P1 | P2 | P3
**Estimated effort:** [hours]
**Depends on:** [other tasks, design docs, approvals]

---

## 1. CONTEXT

[2-3 paragraphs. Why this task exists, what the current state is, what has been tried before (if anything)]

## 2. OBJECTIVE

[ONE sentence. The single deliverable. If you can't state it in one sentence, the scope is too wide — split the task.]

## 3. REFERENCED DOCUMENTS

**Authoritative for this task:**
- `APEX_METHODOLOGY_GROUND_TRUTH.md` (always)
- `<MODULE>_DESIGN_DOC.md` (if structural work)
- `SYSTEM_STATE_LOG.md` (current state)

**ClaudeCode must read these before starting.** If there is conflict between documents, ClaudeCode must STOP and ask.

## 4. SCOPE — WHAT TO DO

**Files ClaudeCode MAY modify:**
- [explicit list]

**Specific changes required:**
1. [very specific instruction with line numbers if applicable]
2. [second change]
3. [etc.]

## 5. SCOPE LOCK — WHAT NOT TO DO

**ClaudeCode MUST NOT:**
- Modify any file not listed in section 4
- Refactor adjacent code "for clarity"
- Add logging/observability not explicitly requested
- Fix other bugs encountered during the task (report in closeout, don't fix)
- Rename variables, functions, or parameters unless explicitly instructed
- Change docstrings beyond what's necessary for new parameters
- Update config files (settings.json, thresholds_gc.json) unless explicitly instructed
- Create new files unless explicitly instructed

**If ClaudeCode encounters another bug or sees an opportunity for improvement, it MUST report in the closeout — not fix it.**

## 6. ACCEPTANCE CRITERIA

[Objective, testable criteria. Each must be verifiable with a specific command or output.]

1. [criterion]
2. [criterion]
3. [etc.]

## 7. PROOF OF EXECUTION (required in closeout)

- [ ] Commit hash on branch [branch_name]
- [ ] `git diff --stat [base]..HEAD` — expected: [specific numbers]
- [ ] `git diff [base]..HEAD` — full, not truncated
- [ ] Files changed: exactly [list]

## 8. PROOF OF FUNCTIONALITY (required in closeout)

[Specific tests to run with expected outputs. Not just `py_compile` — actual execution of the changed code paths.]

- Test 1: [command] → expected output: [text]
- Test 2: [command] → expected output: [text]

## 9. PROOF OF NO-REGRESSION (required in closeout)

[Grep or test commands that confirm nothing else broke.]

- Preservation check: [strings/features that must still exist]
- Compile check: [list of files to py_compile]
- Behavior check: [if applicable]

## 10. CLOSEOUT REPORT REQUIREMENTS

ClaudeCode must produce a TASK_CLOSEOUT_REPORT following the template. Report must include:
- All proofs from sections 7, 8, 9 executed
- Per-instruction status (FIXED / PARTIAL / NOT_ADDRESSED)
- Scope compliance checklist (Y/N for each item in section 5)
- Bugs encountered but not fixed (listed for future tasks)
- Technical debt left
- Self-assessment honesty questions

## 11. GIT WORKFLOW

**Branch:**
```bash
git fetch origin
git checkout -b <branch_name> origin/main
```

**At end:**
```bash
git push origin <branch_name>
# Open PR targeting main
```

**Do NOT merge.** Merge happens after Claude audit.

## 12. ESCALATION RULES

- **Ambiguity:** If any instruction in this spec is ambiguous, ClaudeCode STOPS and asks Barbara.
- **Scope violation required:** If ClaudeCode believes the task cannot be completed within the scope lock, it STOPS and reports — does not proceed.
- **Unexpected state:** If production state differs from what this spec assumes, ClaudeCode STOPS and reports.

---

**ClaudeCode: your response begins with "READ" confirming you read the referenced documents, then proceeds with work. At end, you return the TASK_CLOSEOUT_REPORT. Nothing else.**
